

for i in range (-5,5):
    print(i)